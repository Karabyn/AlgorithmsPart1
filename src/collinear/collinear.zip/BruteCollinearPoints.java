import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Algorithms and Data Structures Part I.
 * Assignment 3.
 * Created by Petro Karabyn on 15-Jul-17.
 */
public class BruteCollinearPoints {

    private final Point[] points;
    private int numOfSegments;
    private List<List<Point>> combinations;

    // finds all line segments2 containing 4 points
    public BruteCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException(); // check for null argument

        for (Point point : points)  if (point == null) throw new IllegalArgumentException(); // check for null points

        for (int i = 0; i < points.length; i++) // check for duplicates
            for (int j = i + 1; j < points.length; j++)
                if (j != i && points[i].slopeTo(points[j]) == Double.NEGATIVE_INFINITY)
                    throw new IllegalArgumentException();

        this.points = points.clone();
        this.numOfSegments = 0;
    }

    // the number of line segments2
    public int numberOfSegments() {
        return combinations.size();
    }

    public LineSegment[] segments() {
        int n = points.length;
        combinations = new ArrayList<>(); // contains all combinations of 4 points.

        // System.out.println("Combination:");
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                for (int k = j + 1; k < n; k++) {
                    for (int l = k + 1; l < n; l++) {
                        // System.out.println(points[i] + ", " + points[j] + ", " + points[k] + ", " + points[l]);
                        // System.out.println(points[i].slopeOrder().compare(points[j], points[k]));
                        if (points[i].slopeOrder().compare(points[j], points[k]) == 0) {
                            // System.out.println(points[i].slopeTo(points[k]) + " = " + points[i].slopeTo(points[l]));
                            if (points[i].slopeTo(points[k]) == points[i].slopeTo(points[l])) {
                                // System.out.println("Collinear");
                                combinations.add(new ArrayList<>());
                                List<Point> currentCombination = combinations.get(numOfSegments);
                                currentCombination.add(points[i]);
                                currentCombination.add(points[j]);
                                currentCombination.add(points[k]);
                                currentCombination.add(points[l]);
                                currentCombination.sort(Comparator.naturalOrder());
                                numOfSegments += 1;
                            }
                        }
                    }
                }
            }
        }

        LineSegment[] lineSegments = new LineSegment[combinations.size()];
        for (int i = 0; i < combinations.size(); i++) {
            lineSegments[i] = new LineSegment(combinations.get(i).get(0), combinations.get(i).get(3));
        }

        return lineSegments;
    }

    /**
     * Find all combinations of 2 points in an array of n point.
     * return an ArrayList c
     */
    /*
    private List<List<Point>> findPairs() {
        List<List<Point>> pairs = new ArrayList<>();
        int counter = 0;
        // find all combinations of 2 points from an array of n points. 2 choose n.
        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                pairs.add(new ArrayList<>());
                pairs.get(counter).add(points[i]);
                pairs.get(counter).add(points[j]);
                counter += 1;
            }
        }
        return pairs;
    }
    */

    /*
    // the line segments2 LineSegment[]
    public List<List<Point>> segments2() {
        List<List<Point>> pairs = new ArrayList<>();
        int counter = 0;
        // find all combinations of 2 points from an array of n points. 2 choose n.
        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                pairs.add(new ArrayList<>());
                pairs.get(counter).add(points[i]);
                pairs.get(counter).add(points[j]);
                counter += 1;
            }
        }
        List<List<Point>> segments = new ArrayList<>();
        for (List<Point> pair : pairs) {
            System.out.println("pair: " + pair);
            for (Point point : points) {
                System.out.println("point: " + point);
                System.out.println("slopes equal: " + (pair.get(0).slopeTo(pair.get(1)) == pair.get(0).slopeTo(point)));
                if (pair.get(0).slopeTo(pair.get(1)) == pair.get(0).slopeTo(point)) { // slopes
                    if (segments.isEmpty()) {
                        segments.add(pair);
                        numOfSegments += 1;
                    }
                    if (segments.size() < numOfSegments) {
                        segments.add(pair);
                        numOfSegments += 1;
                    }

                    segments.get(numOfSegments - 1).add(point);
                    System.out.print("segments2: ");
                    segments.forEach(System.out::print);
                    System.out.println();
                }
            }
        }

        return segments;
    }
    */

    /*
    private Point[][] segments3() {
        Point[][] pairs = new Point[(int) ((1.0/2.0) * (points.length - 1) * points.length)][2];
        int counter = 0;
        for(int i = 0; i < points.length - 1; i++) {
            for(int j = i + 1; j < points.length; j++) {
                pairs[counter][0] = points[i];
                pairs[counter][1] = points[j];
                counter += 1;
            }
        }
        return pairs;
    }
    */

    public static void main(String[] args) {
        /*
        Point[] points = {new Point(0,0), new Point(2,4), new Point(1, 2)}; // new Point(2, 3), new Point(37, 49), new Point(29, 47)
        BruteCollinearPoints brp = new BruteCollinearPoints(points);
        List<List<Point>> list = brp.findPairs();
        Point[][] array = brp.segments3();
        System.out.println("List:");
        list.forEach(System.out::print);
        System.out.println();
        System.out.println("Array:");
        for(int i = 0; i < array.length; i++) {
            System.out.printf("[%s, %s]", array[i][0], array[i][1]);
        }

        System.out.println();
        List<List<Point>> listseg = brp.segments2();
        System.out.println("Segments:");
        listseg.forEach(System.out::print);

        System.out.println();
        System.out.println("Sorted:");
        Point[] points2 =  {new Point(19000,10000), new Point(18000,10000), new Point(32000,10000), new Point(21000,10000), new Point(1234, 5678), new Point(14000, 10000)}; //{new Point(10000,0), new Point(0,10000), new Point(3000,7000), new Point(7000,3000), new Point(20000, 21000), new Point(3000,4000), new Point(14000, 15000), new Point(6000, 7000)}; //{new Point(0,0), new Point(1,1), new Point(2,2), new Point(3,3), new Point(4, 4)};
        Arrays.asList(points2).sort(Comparator.naturalOrder());
        Arrays.asList(points2).forEach(System.out::print);
        System.out.println();

        BruteCollinearPoints brp2 = new BruteCollinearPoints(points2);
        LineSegment[] lineSegments = brp2.segments();
        System.out.println("Line segments:");
        for (LineSegment lineSegment : lineSegments) {
            System.out.println(lineSegment.toString());
        }

        System.out.println("Test: ");
        System.out.println(new Point(10000, 0).slopeTo(new Point(6000, 7000)));

        Point[] points3 = {new Point(0, 0), new Point(1, 1)};
        BruteCollinearPoints brp3 = new BruteCollinearPoints(points3);


        /*
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
        */
    }

}